import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

# Токен вашего бота, полученный от @BotFather
TOKEN = "YOUR_BOT_TOKEN_HERE"
# URL вашего развернутого Web App (например, https://my-ukr-clicker.pages.dev)
WEB_APP_URL = "YOUR_WEB_APP_URL_HERE"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(
        text="🇺🇦 Грати в Козацький Клікер",
        web_app=WebAppInfo(url=WEB_APP_URL)
    ))
    
    welcome_text = (
        f"Привіт, {message.from_user.first_name}! 👋\n\n"
        "Вітаємо у **Козацькому Клікері**! 🌾\n"
        "Клікай на Паляницю, заробляй монети, купуй покращення та відбудовуй українські міста! 🇺🇦\n\n"
        "Натискай кнопку нижче, щоб розпочати гру👇"
    )
    
    await message.answer(welcome_text, reply_markup=builder.as_markup(), parse_mode="Markdown")

if __name__ == "__main__":
    import asyncio
    asyncio.run(dp.start_polling(bot))
